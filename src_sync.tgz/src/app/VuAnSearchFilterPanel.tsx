import React, { useState } from "react";
import { Search, RotateCcw, Calendar, ChevronDown, ChevronUp, X } from "lucide-react";
import { F, RED, BORDER, TEXT, MUTED } from "./shared";
import { LOAI_AN_OPTIONS } from "./data";
import type { UserRoleType } from "./shared";

export const DANH_SACH_TOA_AN_FILTER = [
  "Tòa án nhân dân tối cao",
  "Tòa án nhân dân cấp cao tại Hà Nội",
  "Tòa án nhân dân cấp cao tại Đà Nẵng",
  "Tòa án nhân dân cấp cao tại TP Hồ Chí Minh",
  "Tòa án nhân dân thành phố Hà Nội",
  "Tòa án nhân dân TP Hồ Chí Minh",
  "Tòa án nhân dân TP Hải Phòng",
  "Tòa án nhân dân TP Đà Nẵng",
  "Tòa án nhân dân TP Cần Thơ",
  "Tòa án nhân dân tỉnh Bắc Ninh",
  "Tòa án nhân dân tỉnh An Giang",
  "Tòa án nhân dân tỉnh Vĩnh Phúc",
  "Tòa án nhân dân tỉnh Hà Nam",
];

export const DANH_SACH_LANH_DAO_FILTER = [
  "Phạm Thị Bích Ngọc - Phó Vụ trưởng",
  "Lê Thị Thu Hiền - Phó Vụ trưởng",
  "Nguyễn Như Thắng - Vụ trưởng",
  "Nguyễn Biên Thùy - Phó Vụ trưởng",
  "Trần Hồng Hà - Vụ trưởng",
  "Nguyễn Văn Cường - Phó Vụ trưởng",
];

export const DANH_SACH_TTV_FILTER = [
  "Nguyễn Thị Thúy Hường",
  "Vũ Xuân Hiền",
  "Nguyễn Thị Hường",
  "Nguyễn Đức Thiện",
  "Vũ Diệu Thúy",
  "Đặng Thị Mai",
  "Trần Văn Hưng",
  "Lê Thị Lan",
  "Hoàng Ngọc Chiêu",
  "Đinh Thị Vân Anh",
];

export const DANH_SACH_THAM_PHAN_FILTER = [
  "Lê Thị Thu Hiền",
  "Nguyễn Văn A",
  "Trần Văn B",
  "Phạm Văn C",
  "Nguyễn Thị Hương",
  "Vũ Đức Thiện",
  "Hoàng Ngọc Chiêu",
];

export interface VuAnFilterValues {
  // 12 tiêu chí cơ bản (Grid 4 cột)
  loaiAn: string;
  toaRaBA: string;
  soBA: string;
  ngayBA: string;
  biCao: string;
  nguyenDon: string;
  biDon: string;
  soThuLy: string;
  lanhDaoVu: string;
  thamTraVien: string;
  thamPhan: string;
  thuocAn: string;
  thoiHieu: string;
  hoanTHA: string;

  // Tiêu chí mở rộng (Grid phẳng 4 cột)
  trangThaiHoSo: string;
  thuLyTuNgay: string;
  thuLyDenNgay: string;

  toTrinhLanhDao: string;
  toTrinhTuNgay: string;
  toTrinhDenNgay: string;
  yeuCauTrinhTiep: string;
  yKienToTrinh: string;

  ketQuaGiaiQuyet: string;
  hinhThucDon: string;
  loaiBaGDT: string;
  thuocVu: string;
  hoSoTuNgay: string;
  hoSoDenNgay: string;
  ketQuaTuNgay: string;
  ketQuaDenNgay: string;
  ketQuaXXTuNgay: string;
  ketQuaXXDenNgay: string;
  thongBao: string;
  loaiCongVan: string;
  phanLoaiDon: string;

  capXetXu: string;
  ketQuaXetXu: string;
  ngayTuyenAn: string;

  rutKhangNghi: string;
  ngayRutKhangNghi: string;
  ngayRutKhangNghiDen: string;
}

export const INITIAL_FILTER_VALUES: VuAnFilterValues = {
  loaiAn: "",
  toaRaBA: "",
  soBA: "",
  ngayBA: "",
  biCao: "",
  nguyenDon: "",
  biDon: "",
  soThuLy: "",
  lanhDaoVu: "",
  thamTraVien: "",
  thamPhan: "",
  thuocAn: "",
  thoiHieu: "",
  hoanTHA: "",
  trangThaiHoSo: "",
  thuLyTuNgay: "",
  thuLyDenNgay: "",
  toTrinhLanhDao: "",
  toTrinhTuNgay: "",
  toTrinhDenNgay: "",
  yeuCauTrinhTiep: "",
  yKienToTrinh: "",
  ketQuaGiaiQuyet: "",
  hinhThucDon: "",
  loaiBaGDT: "",
  thuocVu: "",
  hoSoTuNgay: "",
  hoSoDenNgay: "",
  ketQuaTuNgay: "",
  ketQuaDenNgay: "",
  ketQuaXXTuNgay: "",
  ketQuaXXDenNgay: "",
  thongBao: "",
  loaiCongVan: "",
  phanLoaiDon: "",
  capXetXu: "",
  ketQuaXetXu: "",
  ngayTuyenAn: "",
  rutKhangNghi: "",
  ngayRutKhangNghi: "",
  ngayRutKhangNghiDen: "",
};

export const FILTER_LABELS: Record<keyof VuAnFilterValues, string> = {
  loaiAn: "Loại án",
  toaRaBA: "Tòa ra BA/QĐ",
  soBA: "Số BA/QĐ",
  ngayBA: "Ngày BA/QĐ",
  biCao: "Bị cáo",
  nguyenDon: "Nguyên đơn",
  biDon: "Bị đơn",
  soThuLy: "Số thụ lý",
  lanhDaoVu: "Lãnh đạo phụ trách",
  thamTraVien: "Cán bộ giải quyết",
  thamPhan: "Thẩm phán",
  thuocAn: "Thuộc án",
  thoiHieu: "Án thời hiệu",
  hoanTHA: "Hoãn thi hành án",
  trangThaiHoSo: "Trạng thái hồ sơ",
  thuLyTuNgay: "Thụ lý từ ngày",
  thuLyDenNgay: "Thụ lý đến ngày",
  toTrinhLanhDao: "Tờ trình lãnh đạo",
  toTrinhTuNgay: "Tờ trình từ ngày",
  toTrinhDenNgay: "Tờ trình đến ngày",
  yeuCauTrinhTiep: "Yêu cầu trình tiếp",
  yKienToTrinh: "Ý kiến tờ trình",
  ketQuaGiaiQuyet: "Kết quả giải quyết",
  hinhThucDon: "Hình thức đơn",
  loaiBaGDT: "Loại BA GĐT",
  thuocVu: "Thuộc Vụ",
  hoSoTuNgay: "Hồ sơ từ ngày",
  hoSoDenNgay: "Hồ sơ đến ngày",
  ketQuaTuNgay: "Kết quả từ ngày",
  ketQuaDenNgay: "Kết quả đến ngày",
  ketQuaXXTuNgay: "KQ xét xử từ ngày",
  ketQuaXXDenNgay: "KQ xét xử đến ngày",
  thongBao: "Thông báo",
  loaiCongVan: "Loại công văn",
  phanLoaiDon: "Phân loại đơn",
  capXetXu: "Cấp xét xử",
  ketQuaXetXu: "Kết quả xét xử",
  ngayTuyenAn: "Ngày tuyên án",
  rutKhangNghi: "Rút kháng nghị",
  ngayRutKhangNghi: "Rút KN từ ngày",
  ngayRutKhangNghiDen: "Rút KN đến ngày",
};

export function VuAnSearchFilterPanel({
  userRole,
  onSearch,
  onReset,
}: {
  userRole?: UserRoleType;
  onSearch?: (filters: VuAnFilterValues) => void;
  onReset?: () => void;
}) {
  const [filterExpanded, setFilterExpanded] = useState(false);
  const [filters, setFilters] = useState<VuAnFilterValues>(INITIAL_FILTER_VALUES);

  const handleChange = (key: keyof VuAnFilterValues, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const handleRemoveTag = (key: keyof VuAnFilterValues) => {
    setFilters((prev) => {
      const next = { ...prev, [key]: "" };
      if (onSearch) onSearch(next);
      return next;
    });
  };

  const handleReset = () => {
    setFilters(INITIAL_FILTER_VALUES);
    if (onReset) onReset();
  };

  const handleSearch = () => {
    if (onSearch) onSearch(filters);
  };

  const activeTags = Object.entries(filters).filter(([_, val]) => Boolean(val));

  const inputStyle: React.CSSProperties = {
    width: "100%",
    padding: "5px 8px",
    fontSize: 12,
    border: `1px solid ${BORDER}`,
    borderRadius: 4,
    fontFamily: F,
    color: TEXT,
    outline: "none",
    background: "#fff",
    boxSizing: "border-box",
  };

  const selectStyle: React.CSSProperties = {
    ...inputStyle,
    cursor: "pointer",
  };

  const labelStyle: React.CSSProperties = {
    fontSize: 11,
    fontWeight: 600,
    color: "#475569",
    marginBottom: 3,
    fontFamily: F,
    display: "block",
  };

  return (
    <div
      style={{
        background: "#ffffff",
        borderBottom: `1px solid ${BORDER}`,
        padding: "12px 20px",
        flexShrink: 0,
        fontFamily: F,
      }}
    >
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {/* ── BỘ LỌC CƠ BẢN: GRID 4 CỘT ── */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "8px 14px" }}>
          {/* 1. Loại án */}
          <div>
            <label style={labelStyle}>Loại án</label>
            <select value={filters.loaiAn} onChange={(e) => handleChange("loaiAn", e.target.value)} style={selectStyle}>
              <option value="">– Tất cả –</option>
              {LOAI_AN_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>

          {/* 2. Tòa ra BA/QĐ */}
          <div>
            <label style={labelStyle}>Tòa ra BA/QĐ</label>
            <select value={filters.toaRaBA} onChange={(e) => handleChange("toaRaBA", e.target.value)} style={selectStyle}>
              <option value="">– Tất cả –</option>
              {DANH_SACH_TOA_AN_FILTER.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          {/* 3. Số BA/QĐ */}
          <div>
            <label style={labelStyle}>Số BA/QĐ</label>
            <input placeholder="Nhập số BA/QĐ" value={filters.soBA} onChange={(e) => handleChange("soBA", e.target.value)} style={inputStyle} />
          </div>

          {/* 4. Ngày BA/QĐ */}
          <div>
            <label style={labelStyle}>Ngày BA/QĐ</label>
            <div style={{ position: "relative" }}>
              <input placeholder="dd/mm/yyyy" value={filters.ngayBA} onChange={(e) => handleChange("ngayBA", e.target.value)} style={inputStyle} />
              <Calendar size={13} color={MUTED} style={{ position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }} />
            </div>
          </div>

          {/* 5. Bị cáo */}

          <div>

            <label style={labelStyle}>Bị cáo</label>

            <input placeholder="Nhập tên bị cáo" value={filters.biCao} onChange={(e) => handleChange("biCao", e.target.value)} style={inputStyle} />

          </div>


          {/* 5b. Nguyên đơn */}

          <div>

            <label style={labelStyle}>Nguyên đơn</label>

            <input placeholder="Nhập tên nguyên đơn" value={filters.nguyenDon} onChange={(e) => handleChange("nguyenDon", e.target.value)} style={inputStyle} />

          </div>


          {/* 5c. Bị đơn */}

          <div>

            <label style={labelStyle}>Bị đơn</label>

            <input placeholder="Nhập tên bị đơn" value={filters.biDon} onChange={(e) => handleChange("biDon", e.target.value)} style={inputStyle} />

          </div>

          {/* 6. Số thụ lý */}
          <div>
            <label style={labelStyle}>Số thụ lý</label>
            <input placeholder="Nhập số thụ lý" value={filters.soThuLy} onChange={(e) => handleChange("soThuLy", e.target.value)} style={inputStyle} />
          </div>

          {/* 7. Lãnh đạo phụ trách */}
          <div>
            <label style={labelStyle}>Lãnh đạo phụ trách</label>
            <select value={filters.lanhDaoVu} onChange={(e) => handleChange("lanhDaoVu", e.target.value)} style={selectStyle}>
              <option value="">– Tất cả –</option>
              {DANH_SACH_LANH_DAO_FILTER.map((ld) => (
                <option key={ld} value={ld}>{ld}</option>
              ))}
            </select>
          </div>

          {/* 8. Cán bộ giải quyết */}
          <div>
            <label style={labelStyle}>Cán bộ giải quyết</label>
            <select value={filters.thamTraVien} onChange={(e) => handleChange("thamTraVien", e.target.value)} style={selectStyle}>
              <option value="">– Tất cả –</option>
              {DANH_SACH_TTV_FILTER.map((ttv) => (
                <option key={ttv} value={ttv}>{ttv}</option>
              ))}
            </select>
          </div>

          {/* 9. Thẩm phán */}
          <div>
            <label style={labelStyle}>Thẩm phán</label>
            <select value={filters.thamPhan} onChange={(e) => handleChange("thamPhan", e.target.value)} style={selectStyle}>
              <option value="">– Tất cả –</option>
              {DANH_SACH_THAM_PHAN_FILTER.map((tp) => (
                <option key={tp} value={tp}>{tp}</option>
              ))}
            </select>
          </div>

          {/* TH-053: Thuộc Vụ */}
          <div>
            <label style={labelStyle}>Thuộc Vụ</label>
            <select value={filters.thuocVu} onChange={(e) => handleChange("thuocVu", e.target.value)} style={selectStyle}>
              <option value="">– Tất cả –</option>
              <option value="Vụ Giám đốc, kiểm tra I">Vụ Giám đốc, kiểm tra I</option>
              <option value="Vụ Giám đốc, kiểm tra II">Vụ Giám đốc, kiểm tra II</option>
              <option value="Vụ Giám đốc, kiểm tra III">Vụ Giám đốc, kiểm tra III</option>
              <option value="Vụ Giám đốc, kiểm tra IV">Vụ Giám đốc, kiểm tra IV</option>
            </select>
          </div>

          {/* 10. Thuộc án */}
          <div>
            <label style={labelStyle}>Thuộc án</label>
            <select value={filters.thuocAn} onChange={(e) => handleChange("thuocAn", e.target.value)} style={selectStyle}>
              <option value="">– Tất cả –</option>
              <option value="Án Quốc hội">Án Quốc hội</option>
              <option value="Án chỉ đạo">Án chỉ đạo</option>
              <option value="Người chưa thành niên">Người chưa thành niên</option>
              <option value="Án tử hình">Án tử hình</option>
            </select>
          </div>

          {/* 11. Án thời hiệu */}
          <div>
            <label style={labelStyle}>Án thời hiệu</label>
            <select value={filters.thoiHieu} onChange={(e) => handleChange("thoiHieu", e.target.value)} style={selectStyle}>
              <option value="">– Tất cả –</option>
              <option value="Đã hết thời hiệu">Đã hết thời hiệu</option>
              <option value="Còn thời hiệu dưới một tháng">Còn thời hiệu dưới một tháng</option>
              <option value="Còn thời hiệu dưới hai tháng">Còn thời hiệu dưới hai tháng</option>
              <option value="Còn thời hiệu dưới ba tháng">Còn thời hiệu dưới ba tháng</option>
              <option value="Còn thời hiệu dưới sáu tháng">Còn thời hiệu dưới sáu tháng</option>
              <option value="Còn thời hiệu dưới 1 năm">Còn thời hiệu dưới 1 năm</option>
            </select>
          </div>

          {/* 12. Hoãn thi hành án */}
          <div>
            <label style={labelStyle}>Hoãn thi hành án</label>
            <select value={filters.hoanTHA} onChange={(e) => handleChange("hoanTHA", e.target.value)} style={selectStyle}>
              <option value="">– Tất cả –</option>
              <option value="Có">Có</option>
              <option value="Không">Không</option>
            </select>
          </div>
        </div>

        {/* ── MỞ RỘNG BỘ LỌC: PHẲNG DẠNG GRID 4 CỘT TRỰC QUAN (KHÔNG CHIA TAB/BOX BAR) ── */}
        {filterExpanded && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "8px 14px", borderTop: `1px dashed ${BORDER}`, paddingTop: 10 }}>
            {/* Hồ sơ & Thụ lý */}
            <div>
              <label style={labelStyle}>Trạng thái hồ sơ</label>
              <select value={filters.trangThaiHoSo} onChange={(e) => handleChange("trangThaiHoSo", e.target.value)} style={selectStyle}>
                <option value="">– Tất cả –</option>
                <option value="Đã có hồ sơ">Đã có hồ sơ</option>
                <optgroup label="Chưa có hồ sơ">
                  <option value="Chưa có hồ sơ - Đã có phiếu mượn">Đã có phiếu mượn</option>
                  <option value="Chưa có hồ sơ - Chưa có phiếu mượn">Chưa có phiếu mượn</option>
                </optgroup>
              </select>
            </div>
            {/* Thụ lý từ ngày – Đến ngày (Gộp 2 cột thành 1 ô khoảng thời gian) */}
            <div>
              <label style={labelStyle}>Thụ lý từ ngày – Đến ngày</label>
              <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                <input
                  placeholder="Từ ngày"
                  value={filters.thuLyTuNgay}
                  onChange={(e) => handleChange("thuLyTuNgay", e.target.value)}
                  style={{ ...inputStyle, flex: 1 }}
                />
                <span style={{ color: MUTED, fontSize: 11 }}>→</span>
                <div style={{ position: "relative", flex: 1 }}>
                  <input
                    placeholder="Đến ngày"
                    value={filters.thuLyDenNgay}
                    onChange={(e) => handleChange("thuLyDenNgay", e.target.value)}
                    style={inputStyle}
                  />
                  <Calendar size={13} color={MUTED} style={{ position: "absolute", right: 6, top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }} />
                </div>
              </div>
            </div>

            {/* Tờ trình */}
            <div>
              <label style={labelStyle}>Tờ trình lãnh đạo</label>
              <select value={filters.toTrinhLanhDao} onChange={(e) => handleChange("toTrinhLanhDao", e.target.value)} style={selectStyle}>
                <option value="">– Tất cả –</option>
                <option value="Chưa có tờ trình">Chưa có tờ trình</option>
                <option value="Đã có tờ trình">Đã có tờ trình</option>
                <option value="Đã có tờ trình lần 1">Đã có tờ trình lần 1</option>
              </select>
            </div>
            <div>
              <label style={labelStyle}>Tờ trình từ ngày – Đến ngày</label>
              <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                <input
                  placeholder="Từ ngày"
                  value={filters.toTrinhTuNgay}
                  onChange={(e) => handleChange("toTrinhTuNgay", e.target.value)}
                  style={{ ...inputStyle, flex: 1 }}
                />
                <span style={{ color: MUTED, fontSize: 11 }}>→</span>
                <div style={{ position: "relative", flex: 1 }}>
                  <input
                    placeholder="Đến ngày"
                    value={filters.toTrinhDenNgay}
                    onChange={(e) => handleChange("toTrinhDenNgay", e.target.value)}
                    style={inputStyle}
                  />
                  <Calendar size={13} color={MUTED} style={{ position: "absolute", right: 6, top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }} />
                </div>
              </div>
            </div>
            <div>
              <label style={labelStyle}>Ý kiến tờ trình</label>
              <select value={filters.yKienToTrinh} onChange={(e) => handleChange("yKienToTrinh", e.target.value)} style={selectStyle}>
                <option value="">– Tất cả –</option>
                <option value="Chưa có ý kiến">Chưa có ý kiến</option>
                <optgroup label="Đã có ý kiến">
                  <option value="Trả lời đơn">Trả lời đơn</option>
                  <option value="Kháng nghị">Kháng nghị</option>
                  <option value="Xếp đơn">Xếp đơn</option>
                  <option value="Nghiên cứu xác minh, bổ sung">Nghiên cứu xác minh, bổ sung</option>
                  <option value="Yêu cầu trình tiếp">Yêu cầu trình tiếp</option>
                </optgroup>
              </select>
            </div>
            <div>
              <label style={labelStyle}>Yêu cầu trình tiếp</label>
              <select value={filters.yeuCauTrinhTiep} onChange={(e) => handleChange("yeuCauTrinhTiep", e.target.value)} style={selectStyle}>
                <option value="">– Tất cả –</option>
                <option value="Trình Thẩm phán">Trình Thẩm phán</option>
                <option value="Trình Phó Chánh án">Trình Phó Chánh án</option>
                <option value="Trình Chánh án">Trình Chánh án</option>
                <option value="Báo cáo Tổ Thẩm phán">Báo cáo Tổ Thẩm phán</option>
                <option value="Báo cáo Ủy ban thẩm phán">Báo cáo Ủy ban thẩm phán</option>
                <option value="Trình dự thảo trả lời đơn">Trình dự thảo trả lời đơn</option>
                <option value="Trình dự thảo kháng nghị">Trình dự thảo kháng nghị</option>
                <option value="Trả lời đơn">Trả lời đơn</option>
                <option value="Kháng nghị">Kháng nghị</option>
                <option value="Thụ lý xét xử GĐT,TT">Thụ lý xét xử GĐT,TT</option>
                <option value="Xếp đơn">Xếp đơn</option>
                <option value="Xử lý khác">Xử lý khác</option>
                <option value="VKS đang GQ">VKS đang GQ</option>
              </select>
            </div>

            {/* Giải quyết đơn */}
            <div>
              <label style={labelStyle}>Kết quả giải quyết</label>
              <select value={filters.ketQuaGiaiQuyet} onChange={(e) => handleChange("ketQuaGiaiQuyet", e.target.value)} style={selectStyle}>
                <option value="">– Tất cả –</option>
                <option value="Chưa có kết quả">Chưa có kết quả</option>
                <optgroup label="Đã có kết quả">
                  <option value="Trả lời đơn">Trả lời đơn</option>
                  <option value="Kháng nghị (CA + VKS)">Kháng nghị (CA + VKS)</option>
                  <option value="Kháng nghị (CA)">Kháng nghị (CA)</option>
                  <option value="Kháng nghị (VKS)">Kháng nghị (VKS)</option>
                  <option value="Xếp đơn">Xếp đơn</option>
                  <option value="VKS đang nghiên cứu">VKS đang nghiên cứu</option>
                  <option value="Xử lý khác">Xử lý khác</option>
                </optgroup>
              </select>
            </div>
            {/* TH-054: Hồ sơ từ ngày – Đến ngày */}
            <div>
              <label style={labelStyle}>Hồ sơ từ ngày – Đến ngày</label>
              <div style={{ display: "flex", gap: 6 }}>
                <input placeholder="Từ ngày" value={filters.hoSoTuNgay} onChange={(e) => handleChange("hoSoTuNgay", e.target.value)} style={inputStyle} />
                <input placeholder="Đến ngày" value={filters.hoSoDenNgay} onChange={(e) => handleChange("hoSoDenNgay", e.target.value)} style={inputStyle} />
              </div>
            </div>

            {/* TH-055: Kết quả từ ngày – Đến ngày */}
            <div>
              <label style={labelStyle}>Kết quả từ ngày – Đến ngày</label>
              <div style={{ display: "flex", gap: 6 }}>
                <input placeholder="Từ ngày" value={filters.ketQuaTuNgay} onChange={(e) => handleChange("ketQuaTuNgay", e.target.value)} style={inputStyle} />
                <input placeholder="Đến ngày" value={filters.ketQuaDenNgay} onChange={(e) => handleChange("ketQuaDenNgay", e.target.value)} style={inputStyle} />
              </div>
            </div>

            {/* TH-056: Kết quả xét xử từ ngày – Đến ngày */}
            <div>
              <label style={labelStyle}>Kết quả xét xử từ ngày – Đến ngày</label>
              <div style={{ display: "flex", gap: 6 }}>
                <input placeholder="Từ ngày" value={filters.ketQuaXXTuNgay} onChange={(e) => handleChange("ketQuaXXTuNgay", e.target.value)} style={inputStyle} />
                <input placeholder="Đến ngày" value={filters.ketQuaXXDenNgay} onChange={(e) => handleChange("ketQuaXXDenNgay", e.target.value)} style={inputStyle} />
              </div>
            </div>

            {/* TH-057: Thông báo */}
            <div>
              <label style={labelStyle}>Thông báo</label>
              <select value={filters.thongBao} onChange={(e) => handleChange("thongBao", e.target.value)} style={selectStyle}>
                <option value="">– Tất cả –</option>
                <option value="Chưa có thông báo TT">Chưa có thông báo TT</option>
                <option value="Có thông báo TT">Có thông báo TT</option>
                <option value="Chưa có thông báo KQ">Chưa có thông báo KQ</option>
                <option value="Có thông báo KQ">Có thông báo KQ</option>
              </select>
            </div>

            {/* TH-058: Loại công văn */}
            <div>
              <label style={labelStyle}>Loại công văn</label>
              <select value={filters.loaiCongVan} onChange={(e) => handleChange("loaiCongVan", e.target.value)} style={selectStyle}>
                <option value="">– Tất cả –</option>
                <option value="Công văn chuyển đơn">Công văn chuyển đơn</option>
                <option value="Công văn kiến nghị GĐT/TT">Công văn kiến nghị GĐT/TT</option>
                <option value="Công văn trao đổi">Công văn trao đổi</option>
                <option value="Công văn xác minh, bổ sung">Công văn xác minh, bổ sung</option>
                <option value="Công văn khác">Công văn khác</option>
              </select>
            </div>

            <div>
              <label style={labelStyle}>Loại BA GĐT</label>
              <select value={filters.loaiBaGDT} onChange={(e) => handleChange("loaiBaGDT", e.target.value)} style={selectStyle}>
                <option value="">– Tất cả –</option>
                <optgroup label="Đơn đề nghị GĐT,TT">
                  <option value="Đơn đề nghị GĐT">Đơn đề nghị GĐT</option>
                  <option value="Đơn đề nghị TT">Đơn đề nghị TT</option>
                </optgroup>
                <option value="Rút hồ sơ đoàn kiểm tra">Rút hồ sơ đoàn kiểm tra</option>
                <option value="Chủ động GĐT qua Bản án">Chủ động GĐT qua Bản án</option>
              </select>
            </div>

            <div>
              <label style={labelStyle}>Hình thức đơn</label>
              <select value={filters.hinhThucDon} onChange={(e) => handleChange("hinhThucDon", e.target.value)} style={selectStyle}>
                <option value="">– Tất cả –</option>
                <option value="GDT">GĐT</option>
                <option value="CV">Công văn</option>
              </select>
            </div>
            <div>
              <label style={labelStyle}>Phân loại đơn</label>
              <select value={filters.phanLoaiDon} onChange={(e) => handleChange("phanLoaiDon", e.target.value)} style={selectStyle}>
                <option value="">– Tất cả –</option>
                <option value="Đơn đề nghị">Đơn đề nghị</option>
                <option value="Công văn kiến nghị">Công văn kiến nghị</option>
              </select>
            </div>

            {/* Xét xử */}
            <div>
              <label style={labelStyle}>Cấp xét xử</label>
              <select value={filters.capXetXu} onChange={(e) => handleChange("capXetXu", e.target.value)} style={selectStyle}>
                <option value="">– Tất cả –</option>
                <option value="Sơ thẩm">Sơ thẩm</option>
                <option value="Phúc thẩm">Phúc thẩm</option>
                <option value="Giám đốc thẩm">Giám đốc thẩm</option>
                <option value="Tái thẩm">Tái thẩm</option>
              </select>
            </div>
            <div>
              <label style={labelStyle}>Kết quả xét xử</label>
              <input placeholder="Nhập kết quả xét xử" value={filters.ketQuaXetXu} onChange={(e) => handleChange("ketQuaXetXu", e.target.value)} style={inputStyle} />
            </div>
            <div>
              <label style={labelStyle}>Ngày tuyên án</label>
              <input placeholder="dd/mm/yyyy" value={filters.ngayTuyenAn} onChange={(e) => handleChange("ngayTuyenAn", e.target.value)} style={inputStyle} />
            </div>

            {/* Rút kháng nghị */}
            <div>
              <label style={labelStyle}>Rút kháng nghị</label>
              <select value={filters.rutKhangNghi} onChange={(e) => handleChange("rutKhangNghi", e.target.value)} style={selectStyle}>
                <option value="">– Tất cả –</option>
                <option value="Có">Có</option>
                <option value="Không">Không</option>
              </select>
            </div>
            <div>
              <label style={labelStyle}>Rút kháng nghị từ ngày – Đến ngày</label>
              <div style={{ display: "flex", gap: 6 }}>
                <input placeholder="Từ ngày" value={filters.ngayRutKhangNghi} onChange={(e) => handleChange("ngayRutKhangNghi", e.target.value)} style={inputStyle} />
                <input placeholder="Đến ngày" value={filters.ngayRutKhangNghiDen} onChange={(e) => handleChange("ngayRutKhangNghiDen", e.target.value)} style={inputStyle} />
              </div>
            </div>
          </div>
        )}

        {/* ── ACTIVE FILTER TAGS VỚI NÚT XÓA TỪNG TAG ── */}
        {activeTags.length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 6, paddingTop: 4 }}>
            <span style={{ fontSize: 11, fontWeight: 600, color: "#64748b" }}>Đang lọc:</span>
            {activeTags.map(([key, val]) => (
              <span
                key={key}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 5,
                  background: "#eff6ff",
                  border: "1px solid #bfdbfe",
                  color: "#1d4ed8",
                  padding: "2px 8px",
                  borderRadius: 4,
                  fontSize: 11,
                  fontFamily: F,
                }}
              >
                <span style={{ fontWeight: 600 }}>{FILTER_LABELS[key as keyof VuAnFilterValues]}:</span> {val}
                <X
                  size={12}
                  style={{ cursor: "pointer", color: "#2563eb" }}
                  onClick={() => handleRemoveTag(key as keyof VuAnFilterValues)}
                />
              </span>
            ))}
            <button
              onClick={handleReset}
              style={{
                background: "none",
                border: "none",
                color: RED,
                cursor: "pointer",
                fontSize: 11,
                fontWeight: 600,
                fontFamily: F,
                padding: "2px 4px",
              }}
            >
              Xóa tất cả
            </button>
          </div>
        )}

        {/* ── NÚT THAO TÁC (TÌM KIẾM MÀU ĐỎ & XÓA BỘ LỌC) ── */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingTop: 4 }}>
          <button
            onClick={() => setFilterExpanded((v) => !v)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 4,
              background: "none",
              border: "none",
              cursor: "pointer",
              fontSize: 12,
              color: "#2563eb",
              fontFamily: F,
              padding: 0,
              fontWeight: 600,
            }}
          >
            {filterExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            {filterExpanded ? "Thu gọn bộ lọc nâng cao" : "Mở rộng bộ lọc nâng cao"}
          </button>

          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <button
              onClick={handleSearch}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                padding: "6px 20px",
                background: RED,
                color: "#fff",
                border: "none",
                borderRadius: 4,
                cursor: "pointer",
                fontSize: 12,
                fontWeight: 600,
                fontFamily: F,
                boxShadow: "0 1px 2px rgba(0,0,0,0.1)",
              }}
            >
              <Search size={14} /> Tìm kiếm
            </button>

            <button
              onClick={handleReset}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                padding: "6px 14px",
                background: "#fff",
                color: TEXT,
                border: `1px solid ${BORDER}`,
                borderRadius: 4,
                cursor: "pointer",
                fontSize: 12,
                fontFamily: F,
              }}
            >
              <RotateCcw size={13} /> Xóa bộ lọc
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default VuAnSearchFilterPanel;
