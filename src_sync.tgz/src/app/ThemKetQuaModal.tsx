import React, { useState } from "react";
import { FileText, Calendar, X } from "lucide-react";
import { F, RED, BORDER, TEXT, MUTED, TH_STYLE, TD_STYLE } from "./shared";
import { TrinhKyModal } from "./TrinhKyModal";
import { XemBieuMauDuThaoModal } from "./TaoDuThaoModal";
import { TaiLieuHoSoView } from "./TaiLieuHoSoView";

export function ThemKetQuaModal({ onClose, detail }: { onClose: () => void; detail?: any }) {
  const isKhieuNai = detail?.isKhieuNai || detail?.entityWord === "Khiếu nại" || detail?.moduleLabel === "Quản lý khiếu nại" || (typeof detail?.maVuAn === "string" && detail.maVuAn.includes("KN")) || (typeof detail?.id === "string" && detail.id.includes("KN")) || (typeof detail?.tenVuAn === "string" && detail.tenVuAn.toLowerCase().includes("khiếu nại"));
  type KetQua = "tra-loi" | "khang-nghi" | "xep-don" | "vks" | "chap-nhan" | "khong-chap-nhan";
  const [ketQua, setKetQua] = useState<KetQua>(isKhieuNai ? "chap-nhan" : "tra-loi");
  const [showTaiLieuHoSoModal, setShowTaiLieuHoSoModal] = useState(false);

  // Vụ án info summary
  const maVuAn = detail?.maVuAn || "VA26-00321";
  const tenVuAn = detail?.tenVuAn || "Vụ án Phan Văn Thành – bức cung";
  const tenBiCan = detail?.tenBiCan || detail?.biCao || "Phan Văn Thành";
  const toiDanh = detail?.toiDanh || "Bức cung";
  const soBA = detail?.soBA || "050526_CTH02";
  const ngayBA = detail?.ngayBA || "05/05/2026";
  const toaXetXu = detail?.toaXetXu || "Tòa án nhân dân tỉnh Hải Phòng";
  const giaiDoan = detail?.giaiDoan || "Giám đốc thẩm, tái thẩm";
  const toaAnGiaiQuyet = detail?.toaAnGiaiQuyet || "Tòa án nhân dân tối cao";
  const trangThai = detail?.trangThai || "Chưa có kết quả giải quyết đơn";

  // Section 1: Thông tin đơn
  // BR-02: đơn đã có kết quả giải quyết thì không hiện trong danh sách "Đơn liên quan"
  const [donDataList, setDonDataList] = useState([
    {
      id: "don-1",
      label: "1. Đơn 09D732899 - Phạm Minh Tuấn",
      nguoi: ["Phạm Minh Tuấn", "Phạm Văn Nam"],
      daCoKQ: false,
    },
    {
      id: "don-2",
      label: "2. Đơn 10D732900 - Trần Văn Hùng",
      nguoi: ["Trần Văn Hùng"],
      daCoKQ: false,
    },
    {
      id: "don-3",
      label: "3. Đơn 11D732901 - Lê Thị Hoa (đã có KQGQ)",
      nguoi: ["Lê Thị Hoa"],
      daCoKQ: true,
    },
  ]);
  const [donCheckedList, setDonCheckedList] = useState<Record<string, boolean>>({
    "don-1": true,
    "don-1::Phạm Minh Tuấn": true,
    "don-2": true,
    "don-2::Trần Văn Hùng": true,
  });
  const [donExpanded, setDonExpanded] = useState<Record<string, boolean>>({});
  const [donOpen, setDonOpen] = useState(false);
  const [showAddNguoiModal, setShowAddNguoiModal] = useState(false);
  const [newNguoiTen, setNewNguoiTen] = useState("");
  const [newNguoiDonId, setNewNguoiDonId] = useState("don-1");

  const toggleDonCheck = (donId: string) => {
    setDonCheckedList(prev => {
      const next = { ...prev };
      const donObj = donDataList.find(d => d.id === donId);
      const currVal = !prev[donId];
      next[donId] = currVal;
      if (donObj) {
        donObj.nguoi.forEach(n => {
          next[`${donId}::${n}`] = currVal;
        });
      }
      return next;
    });
  };

  const toggleNguoiCheck = (donId: string, nguoiTen: string) => {
    setDonCheckedList(prev => {
      const next = { ...prev };
      const key = `${donId}::${nguoiTen}`;
      next[key] = !prev[key];
      const donObj = donDataList.find(d => d.id === donId);
      if (donObj) {
        const allChecked = donObj.nguoi.every(n => next[`${donId}::${n}`]);
        next[donId] = allChecked;
      }
      return next;
    });
  };

  const getSelectedDonSummary = () => {
    let countDon = 0;
    let countNguoi = 0;
    const selectedItems: string[] = [];

    donDataList.forEach(d => {
      const checkedNguoi = d.nguoi.filter(n => donCheckedList[`${d.id}::${n}`]);
      if (donCheckedList[d.id] || checkedNguoi.length > 0) {
        countDon++;
        checkedNguoi.forEach(n => {
          countNguoi++;
          selectedItems.push(`${n} (${d.label.split(" - ")[0]})`);
        });
      }
    });

    if (countDon === 0 && countNguoi === 0) return "Chọn đơn / người đứng đơn liên quan...";
    return `${countDon} đơn / ${countNguoi} người đứng đơn được chọn (${selectedItems.join(", ")})`;
  };

  const handleAddNewNguoiDungDon = () => {
    if (!newNguoiTen.trim()) {
      alert("Vui lòng nhập tên người đứng đơn!");
      return;
    }
    const name = newNguoiTen.trim();
    setDonDataList(prev => prev.map(d => {
      if (d.id === newNguoiDonId) {
        return { ...d, nguoi: [...d.nguoi, name] };
      }
      return d;
    }));
    setDonCheckedList(prev => ({
      ...prev,
      [`${newNguoiDonId}::${name}`]: true,
    }));
    setNewNguoiTen("");
    setShowAddNguoiModal(false);
  };

  // Section 2: Thông tin quyết định
  const biCaoOptions = Array.from(
    new Set([
      detail?.biCao,
      detail?.tenBiCan,
      "Phan Văn Thành (Bị cáo đầu vụ)",
      "Nguyễn Văn Minh (Bị cáo)",
      "Trần Đình Trọng (Bị cáo)",
      "Lê Văn Hùng (Bị cáo)",
    ].filter(Boolean))
  ) as string[];
  const [selectedBiCao, setSelectedBiCao] = useState<string[]>(biCaoOptions.length ? [biCaoOptions[0]] : []);

  const DEFAULT_HOSO_DATA = [
    {
      id: "HS01",
      label: "📁 Hồ sơ vụ án sơ thẩm (Số 125/2023/HS-ST)",
      files: [
        "Bản án sơ thẩm số 125/2023/HS-ST ngày 15/10/2023",
        "Cáo trạng số 42/CT-VKSNDTC ngày 20/08/2023",
        "Biên bản lấy lời khai bị cáo Phan Văn Thành",
        "Kết luận giám định pháp y thương tích số 88/GĐPY",
      ],
    },
    {
      id: "HS02",
      label: "📁 Hồ sơ chứng cứ & tài liệu bổ sung (Năm 2026)",
      files: [
        "Văn bản kiến nghị xem xét GĐT của Luật sư bào chữa",
        "Chứng cứ mới về thời điểm xảy ra sự việc (Video/Ảnh)",
        "Đơn trình bày bổ sung tình tiết giảm nhẹ của gia đình",
      ],
    },
    {
      id: "HS03",
      label: "📁 Hồ sơ mượn từ TAND tỉnh Long An (Mã mượn HS-LA/2026)",
      files: [
        "Quyết định cho mượn hồ sơ gốc số 14/QĐ-TANDLA",
        "Biên bản giao nhận hồ sơ ngày 10/01/2026",
      ],
    },
    {
      id: "HS04",
      label: "📁 Tiểu hồ sơ nghiên cứu của Thẩm tra viên",
      files: [
        "Báo cáo nghiên cứu hồ sơ của TTV Lý Thái Phúc",
        "Phiếu đề xuất hướng giải quyết kháng nghị GĐT",
      ],
    },
  ];

  const [hoSoOpen, setHoSoOpen] = useState(false);
  const [hoSoExpanded, setHoSoExpanded] = useState<Record<string, boolean>>({ HS01: true });
  const [hoSoCheckedList, setHoSoCheckedList] = useState<Record<string, boolean>>({
    HS01: true,
    "HS01::Bản án sơ thẩm số 125/2023/HS-ST ngày 15/10/2023": true,
    "HS01::Cáo trạng số 42/CT-VKSNDTC ngày 20/08/2023": true,
  });

  const toggleHoSoCheck = (hoSoId: string) => {
    setHoSoCheckedList(prev => {
      const isChecked = !prev[hoSoId];
      const next = { ...prev, [hoSoId]: isChecked };
      const targetHoSo = DEFAULT_HOSO_DATA.find(h => h.id === hoSoId);
      if (targetHoSo) {
        targetHoSo.files.forEach(f => {
          next[`${hoSoId}::${f}`] = isChecked;
        });
      }
      return next;
    });
  };

  const toggleFileCheck = (hoSoId: string, fileName: string) => {
    setHoSoCheckedList(prev => {
      const key = `${hoSoId}::${fileName}`;
      const isChecked = !prev[key];
      const next = { ...prev, [key]: isChecked };
      const targetHoSo = DEFAULT_HOSO_DATA.find(h => h.id === hoSoId);
      if (targetHoSo) {
        const allChecked = targetHoSo.files.every(f => next[`${hoSoId}::${f}`]);
        next[hoSoId] = allChecked;
      }
      return next;
    });
  };

  const getSelectedHoSoSummary = () => {
    const selectedLabels: string[] = [];
    DEFAULT_HOSO_DATA.forEach(h => {
      if (hoSoCheckedList[h.id]) {
        selectedLabels.push(h.label.replace("📁 ", ""));
      } else {
        const checkedFiles = h.files.filter(f => hoSoCheckedList[`${h.id}::${f}`]);
        if (checkedFiles.length > 0) {
          selectedLabels.push(`${h.label.replace("📁 ", "")} (${checkedFiles.length} tài liệu)`);
        }
      }
    });
    if (selectedLabels.length === 0) return "-- Chọn hồ sơ kháng nghị --";
    return selectedLabels.join("; ");
  };

  const [ngayQuyetDinh, setNgayQuyetDinh] = useState("09/08/2026");
  const [soQuyetDinh, setSoQuyetDinh] = useState("");
  const [nguoiKy, setNguoiKy] = useState("Nguyễn Biên Thuỳ - Thẩm phán TANDTC");
  const [ngayPhatHanh, setNgayPhatHanh] = useState("");
  const [noiDung, setNoiDung] = useState("");
  const [selectedVKS, setSelectedVKS] = useState("VKSND Tối cao");
  const [ngayXepDon, setNgayXepDon] = useState("09/08/2026");
  const [nguoiXepDon, setNguoiXepDon] = useState("Nguyễn Hòa Bình – Chánh án");

  const [daLaySo, setDaLaySo] = useState(false);
  const [showTrinhKy, setShowTrinhKy] = useState(false);
  const [showBieuMau, setShowBieuMau] = useState(false);

  // Section 3: Nơi nhận table
  const [noiNhanList, setNoiNhanList] = useState([
    { id: 1, noiNhan: "Khác", noiNhanChiTiet: "Như kính gửi", ghiChu: "–" },
    { id: 2, noiNhan: "Tòa án nhân dân", noiNhanChiTiet: "Đ/c Chánh án TANDTC", ghiChu: "để báo cáo" },
  ]);

  const [isAddingNoiNhan, setIsAddingNoiNhan] = useState(false);
  const [newNoiNhan, setNewNoiNhan] = useState("Khác");
  const [newChiTiet, setNewChiTiet] = useState("");
  const [newGhiChu, setNewGhiChu] = useState("");

  const [editingId, setEditingId] = useState<number | null>(null);
  const [editNoiNhan, setEditNoiNhan] = useState("");
  const [editChiTiet, setEditChiTiet] = useState("");
  const [editGhiChu, setEditGhiChu] = useState("");

  const handleStartEdit = (r: { id: number; noiNhan: string; noiNhanChiTiet: string; ghiChu: string }) => {
    setEditingId(r.id);
    setEditNoiNhan(r.noiNhan);
    setEditChiTiet(r.noiNhanChiTiet);
    setEditGhiChu(r.ghiChu);
  };

  const handleSaveEdit = (id: number) => {
    if (!editChiTiet.trim()) {
      alert("Vui lòng nhập nơi nhận chi tiết!");
      return;
    }
    setNoiNhanList(prev =>
      prev.map(item =>
        item.id === id
          ? { ...item, noiNhan: editNoiNhan, noiNhanChiTiet: editChiTiet.trim(), ghiChu: editGhiChu.trim() || "–" }
          : item
      )
    );
    setEditingId(null);
  };

  const handleSaveNewNoiNhan = () => {
    if (!newChiTiet.trim()) {
      alert("Vui lòng nhập nơi nhận chi tiết!");
      return;
    }
    setNoiNhanList(prev => [
      ...prev,
      {
        id: Date.now(),
        noiNhan: newNoiNhan,
        noiNhanChiTiet: newChiTiet.trim(),
        ghiChu: newGhiChu.trim() || "–",
      },
    ]);
    setIsAddingNoiNhan(false);
    setNewChiTiet("");
    setNewGhiChu("");
  };

  const handleDeleteNoiNhan = (id: number) => {
    setNoiNhanList(prev => prev.filter(item => item.id !== id));
  };

  const handleToggleLaySo = () => {
    if (!daLaySo) {
      const num = Math.floor(Math.random() * 900 + 100);
      const generated = `${num}/2026/${ketQua === "khang-nghi" ? "QĐ-TANDTC" : "TB-TANDTC"}`;
      setSoQuyetDinh(generated);
      setDaLaySo(true);
      alert(`Đã cấp số quyết định/văn bản thành công: ${generated}`);
    } else {
      setSoQuyetDinh("");
      setDaLaySo(false);
      alert("Đã hủy cấp số!");
    }
  };

  const handleSave = () => {
    alert("Đã lưu kết quả giải quyết văn bản đề nghị thành công!");
    onClose();
  };

  const inSt: React.CSSProperties = {
    padding: "7px 10px",
    fontSize: 12,
    border: `1px solid ${BORDER}`,
    borderRadius: 4,
    fontFamily: F,
    outline: "none",
    width: "100%",
    background: "#fff",
    boxSizing: "border-box",
  };
  const lblSt: React.CSSProperties = {
    fontSize: 12,
    color: "#374151",
    fontWeight: 600,
    fontFamily: F,
    display: "block",
    marginBottom: 4,
  };

  const THAM_QUYEN_XET_XU_OPTIONS = [
    "Ủy ban Thẩm phán Tòa án nhân dân cấp cao",
    "Hội đồng Thẩm phán Tòa án nhân dân tối cao",
    "Tòa án nhân dân cấp cao tại Hà Nội",
    "Tòa án nhân dân cấp cao tại Đà Nẵng",
    "Tòa án nhân dân cấp cao tại TP. Hồ Chí Minh",
  ];
  const QUYET_DINH_KN_OPTIONS = [
    "Hủy bản án/quyết định đã có hiệu lực pháp luật để xét xử lại",
    "Hủy bản án/quyết định đã có hiệu lực pháp luật về phần…",
    "Hủy bản án/quyết định đã có hiệu lực pháp luật và đình chỉ giải quyết vụ án",
    "Sửa một phần bản án/quyết định đã có hiệu lực pháp luật",
    "Giữ nguyên bản án/quyết định đã có hiệu lực pháp luật",
  ];

  const RADIO_OPTIONS: { value: KetQua; label: string }[] = isKhieuNai ? [
    { value: "chap-nhan", label: "Chấp nhận khiếu nại" },
    { value: "khong-chap-nhan", label: "Không chấp nhận khiếu nại" },
    { value: "xep-don", label: "Xếp đơn" },
  ] : [
    { value: "khang-nghi", label: "Kháng nghị" },
    { value: "tra-loi", label: "Trả lời đơn" },
    { value: "xep-don", label: "Xếp đơn" },
    { value: "vks", label: "Viện kiểm sát đang giải quyết" },
  ];

  const [hinhThucTrinh, setHinhThucTrinh] = useState("trinh-ky");
  const [noiDungDuyetKy, setNoiDungDuyetKy] = useState("");
  const [thamQuyenXetXu, setThamQuyenXetXu] = useState("");
  const [noiDungVuAn, setNoiDungVuAn] = useState("");
  const [xetThay, setXetThay] = useState("");
  const [quyetDinhKN, setQuyetDinhKN] = useState("");
  const [congVanVKS, setCongVanVKS] = useState<Array<{ id: number; hinhThuc: string; ten: string; so: string; ngay: string; donVi: string }>>([]);

  const isTraLoi = ketQua === "tra-loi";
  const isKhangNghi = ketQua === "khang-nghi";
  const isXepDon = ketQua === "xep-don";
  const isVks = ketQua === "vks";
  const showNoiNhan = isTraLoi || isVks || isKhangNghi || ketQua === "chap-nhan" || ketQua === "khong-chap-nhan";
  const VKS_OPTIONS = ["VKSND Tối cao", "VKSND cấp cao tại Hà Nội", "VKSND cấp cao tại TP. HCM", "VKSND cấp cao tại Đà Nẵng"];

  return (
    <>
      <div style={{ position: "fixed", inset: 0, zIndex: 1100, background: "rgba(0,0,0,0.45)", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ background: "#fff", borderRadius: 8, width: "min(920px, 96vw)", maxHeight: "94vh", display: "flex", flexDirection: "column", boxShadow: "0 8px 32px rgba(0,0,0,0.2)", fontFamily: F, overflow: "hidden" }}>
          {/* Header */}
          <div style={{ display: "flex", alignItems: "center", padding: "14px 20px", borderBottom: `1px solid ${BORDER}`, flexShrink: 0 }}>
            <FileText size={16} color={RED} style={{ marginRight: 8 }} />
            <span style={{ fontSize: 15, fontWeight: 700, color: TEXT, flex: 1 }}>
              {isKhieuNai ? "Thêm kết quả giải quyết khiếu nại" : "Tạo kết quả giải quyết văn bản đề nghị"}
            </span>
            <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", padding: 4, display: "flex" }}>
              <X size={18} color={MUTED} />
            </button>
          </div>

          <div style={{ flex: 1, overflowY: "auto", padding: "16px 20px", display: "flex", flexDirection: "column", gap: 16 }}>
            {/* Info card */}
            <div
              style={{
                background: "#f8fafc",
                border: `1px solid ${BORDER}`,
                borderRadius: 6,
                padding: "12px 16px",
              }}
            >
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "1.1fr 1fr 1fr",
                  gap: "8px 16px",
                  fontSize: 12,
                  fontFamily: F,
                  lineHeight: 1.5,
                }}
              >
                {/* Col 1 */}
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  <div>
                    <span style={{ color: "#374151" }}>Mã vụ án: </span>
                    <span style={{ color: "#0f766e", fontWeight: 700 }}>{maVuAn}</span>
                  </div>
                  <div>
                    <span style={{ color: "#374151" }}>Tên vụ án: </span>
                    <span style={{ color: "#0f766e", fontWeight: 600 }}>{tenVuAn}</span>
                  </div>
                  <div>
                    <span style={{ color: "#374151" }}>Tên bị can đầu vụ: </span>
                    <span style={{ color: "#0f766e", fontWeight: 600 }}>{tenBiCan}</span>
                  </div>
                  <div>
                    <span style={{ color: "#374151" }}>Tội danh chính: </span>
                    <span style={{ color: "#0f766e", fontWeight: 600 }}>{toiDanh}</span>
                  </div>
                </div>

                {/* Col 2 */}
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  <div>
                    <span style={{ color: "#374151" }}>Số BA/QĐ: </span>
                    <span style={{ color: "#0f766e", fontWeight: 600 }}>{soBA}</span>
                  </div>
                  <div>
                    <span style={{ color: "#374151" }}>Ngày ra BA/QĐ: </span>
                    <span style={{ color: "#0f766e", fontWeight: 600 }}>{ngayBA}</span>
                  </div>
                  <div>
                    <span style={{ color: "#374151" }}>Tòa xét xử: </span>
                    <span style={{ color: "#0f766e", fontWeight: 600 }}>{toaXetXu}</span>
                  </div>
                </div>

                {/* Col 3 */}
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  <div>
                    <span style={{ color: "#374151" }}>Giai đoạn: </span>
                    <span style={{ color: "#0f766e", fontWeight: 600 }}>{giaiDoan}</span>
                  </div>
                  <div>
                    <span style={{ color: "#374151" }}>Tòa án giải quyết: </span>
                    <span style={{ color: "#0f766e", fontWeight: 600 }}>{toaAnGiaiQuyet}</span>
                  </div>
                  <div>
                    <span style={{ color: "#374151" }}>Trạng thái: </span>
                    <span style={{ color: "#dc2626", fontWeight: 700 }}>{trangThai}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Section 1: Thông tin đơn */}
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: "#800000", fontFamily: F, display: "flex", alignItems: "center", gap: 6 }}>
                <span>■ Thông tin đơn</span>
              </div>

              {/* TH-088: chọn hình thức trình và nội dung duyệt ký */}
              {(isTraLoi || isVks || isKhangNghi) && (
                <div style={{ marginBottom: 12 }}>
                  <label style={lblSt}>Hình thức trình</label>
                  <div style={{ display: "flex", gap: 20, marginBottom: 8 }}>
                    {[{ v: "trinh-duyet", l: "Trình duyệt" }, { v: "trinh-ky", l: "Trình ký" }].map(o => (
                      <label key={o.v} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, cursor: "pointer", fontFamily: F }}>
                        <input type="radio" name="hinh-thuc-trinh" checked={hinhThucTrinh === o.v}
                          onChange={() => setHinhThucTrinh(o.v)} style={{ accentColor: "#800000", cursor: "pointer" }} />
                        <span style={{ fontWeight: hinhThucTrinh === o.v ? 700 : 400 }}>{o.l}</span>
                      </label>
                    ))}
                  </div>
                  <label style={lblSt}>Nội dung duyệt ký</label>
                  <textarea value={noiDungDuyetKy} onChange={e => setNoiDungDuyetKy(e.target.value)}
                    placeholder="Nhập nội dung trình duyệt / trình ký"
                    style={{ ...inSt, minHeight: 56, resize: "vertical" }} />
                </div>
              )}

              {!isKhieuNai && (
                <div>
                  {/* <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 5 }}>
                    <label style={lblSt}>
                      <span style={{ color: "#dc2626", marginRight: 3 }}>*</span>Đơn liên quan / Người đứng đơn
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowAddNguoiModal(true)}
                      style={{
                        background: "none",
                        border: "none",
                        color: "#800000",
                        fontSize: 12,
                        fontWeight: 700,
                        cursor: "pointer",
                        fontFamily: F,
                        display: "flex",
                        alignItems: "center",
                        gap: 4,
                      }}
                    >
                      + Thêm người đứng đơn
                    </button>
                  </div> */}

                  <div style={{ position: "relative" }}>
                    <div
                      onClick={() => setDonOpen(o => !o)}
                      style={{
                        ...inSt,
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        userSelect: "none",
                        minHeight: 34,
                        background: "#fff",
                      }}
                    >
                      <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: "#111827", fontWeight: 500 }}>
                        {getSelectedDonSummary()}
                      </span>
                      <span style={{ fontSize: 10, color: "#6b7280", marginLeft: 6 }}>{donOpen ? "▲" : "▼"}</span>
                    </div>

                    {donOpen && (
                      <div
                        style={{
                          position: "absolute",
                          top: "100%",
                          left: 0,
                          right: 0,
                          zIndex: 300,
                          background: "#fff",
                          border: "1px solid #d1d5db",
                          borderRadius: 4,
                          boxShadow: "0 6px 20px rgba(0,0,0,0.15)",
                          maxHeight: 280,
                          overflowY: "auto",
                          marginTop: 4,
                        }}
                      >
                        {donDataList.filter(d => !d.daCoKQ).map(don => {
                          const isWholeDonChecked = !!donCheckedList[don.id];
                          const isExpanded = !!donExpanded[don.id];
                          const anyNguoiChecked = don.nguoi.some(n => donCheckedList[`${don.id}::${n}`]);
                          return (
                            <div key={don.id}>
                              <div
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 8,
                                  padding: "8px 12px",
                                  borderBottom: "1px solid #e5e7eb",
                                  background: isWholeDonChecked || anyNguoiChecked ? "#fef2f2" : "#fff",
                                }}
                              >
                                <input
                                  type="checkbox"
                                  checked={isWholeDonChecked}
                                  ref={el => { if (el) el.indeterminate = !isWholeDonChecked && anyNguoiChecked; }}
                                  onChange={() => toggleDonCheck(don.id)}
                                  style={{ accentColor: "#800000", cursor: "pointer", flexShrink: 0 }}
                                />
                                <span style={{ flex: 1, fontSize: 12, fontWeight: 600, color: "#111827" }}>
                                  {don.label}
                                </span>
                                <button
                                  type="button"
                                  onClick={e => { e.stopPropagation(); setDonExpanded(p => ({ ...p, [don.id]: !p[don.id] })); }}
                                  style={{ background: "none", border: "none", cursor: "pointer", fontSize: 11, color: "#2563eb", padding: "2px 4px" }}
                                >
                                  {isExpanded ? "▲ Thu gọn người đứng đơn" : `▼ Xem ${don.nguoi.length} người đứng đơn`}
                                </button>
                              </div>
                              {isExpanded && don.nguoi.map(nguoi => (
                                <div
                                  key={nguoi}
                                  style={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 8,
                                    padding: "6px 12px 6px 32px",
                                    borderBottom: "1px solid #f3f4f6",
                                    background: donCheckedList[`${don.id}::${nguoi}`] ? "#fff5f5" : "#fafafa",
                                  }}
                                >
                                  <input
                                    type="checkbox"
                                    checked={!!donCheckedList[`${don.id}::${nguoi}`] || isWholeDonChecked}
                                    onChange={() => toggleNguoiCheck(don.id, nguoi)}
                                    style={{ accentColor: "#800000", cursor: "pointer", flexShrink: 0 }}
                                  />
                                  <span style={{ fontSize: 12, color: "#111827" }}>👤 {nguoi}</span>
                                </div>
                              ))}
                            </div>
                          );
                        })}
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 12px", borderTop: "1px solid #e5e7eb", background: "#f9fafb" }}>
                          <button
                            type="button"
                            onClick={() => { setShowAddNguoiModal(true); setDonOpen(false); }}
                            style={{ fontSize: 11, color: "#800000", fontWeight: 700, background: "none", border: "none", cursor: "pointer" }}
                          >
                            + Thêm mới người đứng đơn
                          </button>
                          <button
                            type="button"
                            onClick={() => setDonOpen(false)}
                            style={{ padding: "5px 16px", background: "#800000", color: "#fff", border: "none", borderRadius: 4, cursor: "pointer", fontSize: 12, fontWeight: 600 }}
                          >
                            Xác nhận
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div>
                <label style={lblSt}>
                  <span style={{ color: "#dc2626", marginRight: 3 }}>*</span>Kết quả giải quyết đơn
                </label>
                <div style={{ display: "flex", gap: 20, alignItems: "center", marginTop: 4, flexWrap: "wrap" }}>
                  {RADIO_OPTIONS.map(o => (
                    <label key={o.value} style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer", fontSize: 13, fontFamily: F, color: "#111827" }}>
                      <input
                        type="radio"
                        name="ketqua-tkq"
                        checked={ketQua === o.value}
                        onChange={() => setKetQua(o.value)}
                        style={{ accentColor: "#800000", cursor: "pointer" }}
                      />
                      <span style={{ fontWeight: ketQua === o.value ? 700 : 400 }}>{o.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {isKhangNghi && (
                <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 4 }}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                    <div>
                      <label style={lblSt}>
                        <span style={{ color: "#dc2626", marginRight: 3 }}>*</span>Chọn Bị cáo (giữ Ctrl để chọn nhiều)
                      </label>
                      <select
                        multiple
                        value={selectedBiCao}
                        onChange={e => setSelectedBiCao(Array.from(e.target.selectedOptions, o => o.value))}
                        style={{ ...inSt, cursor: "pointer", height: 92 }}
                      >
                        {biCaoOptions.map(bc => (
                          <option key={bc} value={bc}>{bc}</option>
                        ))}
                      </select>
                    </div>

                  </div>
                </div>
              )}
            </div>

            {/* Section 2: Thông tin quyết định */}
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: "#800000", fontFamily: F, display: "flex", alignItems: "center", gap: 6 }}>
                <span>■ Thông tin quyết định</span>
              </div>

              {(isTraLoi || isKhangNghi || isVks || ketQua === "chap-nhan" || ketQua === "khong-chap-nhan") && (
                <>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 12 }}>
                    <div>
                      <label style={lblSt}>Ngày quyết định</label>
                      <div style={{ position: "relative" }}>
                        <input
                          type="text"
                          value={ngayQuyetDinh}
                          onChange={e => setNgayQuyetDinh(e.target.value)}
                          placeholder="Chọn ngày quyết định"
                          style={{ ...inSt, paddingRight: 28 }}
                        />
                        <Calendar size={14} color="#9ca3af" style={{ position: "absolute", right: 8, top: 9, pointerEvents: "none" }} />
                      </div>
                    </div>

                    <div>
                      <label style={lblSt}>Số quyết định</label>
                      <input
                        type="text"
                        value={soQuyetDinh}
                        onChange={e => setSoQuyetDinh(e.target.value)}
                        placeholder="Nhập số quyết định"
                        style={inSt}
                      />
                    </div>

                    <div>
                      <label style={lblSt}>
                        <span style={{ color: "#dc2626", marginRight: 3 }}>*</span>Người ký ban hành
                      </label>
                      <select
                        value={nguoiKy}
                        onChange={e => setNguoiKy(e.target.value)}
                        style={{ ...inSt, cursor: "pointer" }}
                      >
                        <option value="Nguyễn Biên Thuỳ - Thẩm phán TANDTC">Nguyễn Biên Thuỳ - Thẩm phán TANDTC</option>
                        <option value="Phan Văn Nam - Phó Chánh án TANDTC">Phan Văn Nam - Phó Chánh án TANDTC</option>
                        <option value="Nguyễn Hòa Bình – Chánh án">Nguyễn Hòa Bình – Chánh án</option>
                        <option value="Lê Minh Trí – Phó Chánh án">Lê Minh Trí – Phó Chánh án</option>
                        <option value="Lê Hoàng Nam - Vụ trưởng Vụ 1">Lê Hoàng Nam - Vụ trưởng Vụ 1</option>
                        <option value="Lý Thái Phúc - Thẩm tra viên">Lý Thái Phúc - Thẩm tra viên</option>
                      </select>
                    </div>

                    <div>
                      <label style={lblSt}>Ngày phát hành</label>
                      <div style={{ position: "relative" }}>
                        <input
                          type="text"
                          value={ngayPhatHanh}
                          onChange={e => setNgayPhatHanh(e.target.value)}
                          placeholder="Chọn ngày phát hành"
                          style={{ ...inSt, paddingRight: 28 }}
                        />
                        <Calendar size={14} color="#9ca3af" style={{ position: "absolute", right: 8, top: 9, pointerEvents: "none" }} />
                      </div>
                    </div>
                  </div>

                  {isKhangNghi && (
                    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                      <div style={{ maxWidth: 380 }}>
                        <label style={lblSt}>
                          <span style={{ color: "#dc2626", marginRight: 3 }}>*</span>Thẩm quyền xét xử
                        </label>
                        <select value={thamQuyenXetXu} onChange={e => setThamQuyenXetXu(e.target.value)} style={{ ...inSt, cursor: "pointer" }}>
                          <option value="">-- Chọn thẩm quyền xét xử --</option>
                          {THAM_QUYEN_XET_XU_OPTIONS.map(t => <option key={t} value={t}>{t}</option>)}
                        </select>
                      </div>
                      <div>
                        <label style={lblSt}>
                          <span style={{ color: "#dc2626", marginRight: 3 }}>*</span>Nội dung vụ án
                        </label>
                        <textarea value={noiDungVuAn} onChange={e => setNoiDungVuAn(e.target.value)}
                          placeholder="Tóm tắt nội dung vụ án"
                          style={{ ...inSt, minHeight: 70, resize: "vertical" }} />
                      </div>
                      <div>
                        <label style={lblSt}>
                          <span style={{ color: "#dc2626", marginRight: 3 }}>*</span>Xét thấy
                        </label>
                        <textarea value={xetThay} onChange={e => setXetThay(e.target.value)}
                          placeholder="Nhận xét, phân tích, căn cứ pháp lý"
                          style={{ ...inSt, minHeight: 70, resize: "vertical" }} />
                      </div>
                      <div>
                        <label style={lblSt}>
                          <span style={{ color: "#dc2626", marginRight: 3 }}>*</span>Quyết định
                        </label>
                        <select value={quyetDinhKN} onChange={e => setQuyetDinhKN(e.target.value)} style={{ ...inSt, cursor: "pointer" }}>
                          <option value="">-- Chọn quyết định --</option>
                          {QUYET_DINH_KN_OPTIONS.map(q => <option key={q} value={q}>{q}</option>)}
                        </select>
                      </div>
                    </div>
                  )}

                  {isVks && (
                    <div style={{ maxWidth: 380 }}>
                      <label style={lblSt}>
                        <span style={{ color: "#dc2626", marginRight: 3 }}>*</span>Viện kiểm sát đang giải quyết
                      </label>
                      <select
                        value={selectedVKS}
                        onChange={e => setSelectedVKS(e.target.value)}
                        style={{ ...inSt, cursor: "pointer" }}
                      >
                        {VKS_OPTIONS.map(v => <option key={v} value={v}>{v}</option>)}
                      </select>

                      {/* TH-084: thông tin quyết định / công văn của VKS */}
                      <div style={{ marginTop: 12, maxWidth: "100%" }}>
                        <div style={{ display: "flex", alignItems: "center", marginBottom: 8 }}>
                          <span style={{ fontSize: 12, fontWeight: 700, color: "#374151", flex: 1 }}>Thông tin quyết định / công văn</span>
                          <button
                            onClick={() => setCongVanVKS(prev => [...prev, { id: Date.now(), hinhThuc: "Công văn", ten: "", so: "", ngay: "", donVi: "" }])}
                            style={{ padding: "4px 12px", background: "#800000", color: "#fff", border: "none", borderRadius: 4, cursor: "pointer", fontSize: 12, fontWeight: 600 }}>
                            Thêm công văn
                          </button>
                        </div>
                        <table style={{ width: "100%", borderCollapse: "collapse", border: "1px solid #e5e7eb" }}>
                          <thead>
                            <tr style={{ background: "#f9fafb" }}>
                              {["Hình thức", "Tên CV/QĐ", "Số CV", "Ngày CV", "Đơn vị tạo/nhận", ""].map(h => (
                                <th key={h} style={{ padding: "6px 8px", fontSize: 11, fontWeight: 700, color: "#6b7280", textAlign: "left", border: "1px solid #e5e7eb" }}>{h}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {congVanVKS.length === 0 && (
                              <tr><td colSpan={6} style={{ padding: 12, fontSize: 12, color: "#9ca3af", textAlign: "center", border: "1px solid #e5e7eb" }}>Chưa có công văn</td></tr>
                            )}
                            {congVanVKS.map((cv, i) => (
                              <tr key={cv.id}>
                                <td style={{ border: "1px solid #e5e7eb", padding: 4 }}>
                                  <select value={cv.hinhThuc} onChange={e => setCongVanVKS(prev => prev.map((x, j) => j === i ? { ...x, hinhThuc: e.target.value } : x))}
                                    style={{ width: "100%", border: "none", fontSize: 12, outline: "none" }}>
                                    <option>Công văn</option><option>Quyết định</option>
                                  </select>
                                </td>
                                {(["ten", "so", "ngay", "donVi"] as const).map(k => (
                                  <td key={k} style={{ border: "1px solid #e5e7eb", padding: 4 }}>
                                    <input value={cv[k]} onChange={e => setCongVanVKS(prev => prev.map((x, j) => j === i ? { ...x, [k]: e.target.value } : x))}
                                      style={{ width: "100%", border: "none", fontSize: 12, outline: "none" }} />
                                  </td>
                                ))}
                                <td style={{ border: "1px solid #e5e7eb", padding: 4, textAlign: "center" }}>
                                  <button onClick={() => setCongVanVKS(prev => prev.filter((_, j) => j !== i))}
                                    style={{ background: "none", border: "none", cursor: "pointer", color: "#ef4444", fontSize: 12 }}>Xóa</button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  <div>
                    <label style={lblSt}>
                      <span style={{ color: "#dc2626", marginRight: 3 }}>*</span>
                      {isKhangNghi
                        ? "Nội dung quyết định kháng nghị"
                        : isVks
                          ? "Nội dung chuyển Viện kiểm sát giải quyết"
                          : "Nội dung trả lời"}
                    </label>
                    <textarea
                      value={noiDung}
                      onChange={e => setNoiDung(e.target.value)}
                      placeholder={isKhangNghi ? "Nhập nội dung quyết định kháng nghị..." : "Nhập nội dung trả lời..."}
                      rows={3}
                      style={{ ...inSt, resize: "vertical", lineHeight: 1.5 }}
                    />
                  </div>
                </>
              )}

              {isXepDon && (
                <>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    <div>
                      <label style={lblSt}>
                        <span style={{ color: "#dc2626", marginRight: 3 }}>*</span>Ngày xếp đơn
                      </label>
                      <div style={{ position: "relative" }}>
                        <input
                          type="text"
                          value={ngayXepDon}
                          onChange={e => setNgayXepDon(e.target.value)}
                          placeholder="Chọn ngày xếp đơn"
                          style={{ ...inSt, paddingRight: 28 }}
                        />
                        <Calendar size={14} color="#9ca3af" style={{ position: "absolute", right: 8, top: 9, pointerEvents: "none" }} />
                      </div>
                    </div>

                    <div>
                      <label style={lblSt}>
                        <span style={{ color: "#dc2626", marginRight: 3 }}>*</span>Người quyết định xếp đơn
                      </label>
                      <select
                        value={nguoiXepDon}
                        onChange={e => setNguoiXepDon(e.target.value)}
                        style={{ ...inSt, cursor: "pointer" }}
                      >
                        <option value="Nguyễn Hòa Bình – Chánh án">Nguyễn Hòa Bình – Chánh án</option>
                        <option value="Lê Minh Trí – Phó Chánh án">Lê Minh Trí – Phó Chánh án</option>
                        <option value="Nguyễn Thị Bình – Vụ trưởng">Nguyễn Thị Bình – Vụ trưởng</option>
                        <option value="Lê Hoàng Nam - Vụ trưởng Vụ 1">Lê Hoàng Nam - Vụ trưởng Vụ 1</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label style={lblSt}>Ghi chú</label>
                    <textarea
                      value={noiDung}
                      onChange={e => setNoiDung(e.target.value)}
                      placeholder="Nhập lý do xếp đơn..."
                      rows={3}
                      style={{ ...inSt, resize: "vertical", lineHeight: 1.5 }}
                    />
                  </div>
                </>
              )}
            </div>

            {/* Section 3: Nơi nhận */}
            {showNoiNhan && (
              <div>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                  <label style={{ ...lblSt, marginBottom: 0, fontWeight: 600 }}>
                    <span style={{ color: "#dc2626", marginRight: 3 }}>*</span>Nơi nhận
                  </label>
                  <button
                    type="button"
                    onClick={() => setIsAddingNoiNhan(true)}
                    style={{
                      background: "#800000",
                      color: "#fff",
                      border: "none",
                      borderRadius: 4,
                      padding: "5px 14px",
                      fontSize: 12,
                      fontWeight: 700,
                      fontFamily: F,
                      cursor: "pointer",
                    }}
                  >
                    + Thêm nơi nhận
                  </button>
                </div>

                <div style={{ border: `1px solid ${BORDER}`, borderRadius: 4, overflow: "hidden" }}>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12, fontFamily: F }}>
                    <thead>
                      <tr style={{ background: "#f8fafc", borderBottom: `1px solid ${BORDER}` }}>
                        <th style={{ ...TH_STYLE, width: 45, textAlign: "center" }}>STT</th>
                        <th style={{ ...TH_STYLE, width: 160 }}>Nơi nhận</th>
                        <th style={{ ...TH_STYLE, width: 220 }}>Nơi nhận chi tiết</th>
                        <th style={{ ...TH_STYLE }}>Ghi chú</th>
                        <th style={{ ...TH_STYLE, width: 90, textAlign: "center" }}>Thao tác</th>
                      </tr>
                    </thead>
                    <tbody>
                      {noiNhanList.map((r, idx) => (
                        <tr key={r.id} style={{ borderBottom: `1px solid ${BORDER}`, background: idx % 2 === 0 ? "#fff" : "#fafafa" }}>
                          <td style={{ ...TD_STYLE, textAlign: "center", color: MUTED }}>{idx + 1}</td>
                          <td style={TD_STYLE}>
                            {editingId === r.id ? (
                              <select
                                value={editNoiNhan}
                                onChange={e => setEditNoiNhan(e.target.value)}
                                style={{ ...inSt, padding: "4px 8px" }}
                              >
                                <option value="Khác">Khác</option>
                                <option value="Tòa án nhân dân">Tòa án nhân dân</option>
                                <option value="Viện kiểm sát nhân dân">Viện kiểm sát nhân dân</option>
                                <option value="Cơ quan thi hành án hình sự">Cơ quan thi hành án hình sự</option>
                                <option value="Cơ quan thi hành án dân sự">Cơ quan thi hành án dân sự</option>
                                <option value="Trại giam">Trại giam</option>
                                <option value="Trại tạm giam">Trại tạm giam</option>
                                <option value="Viện kiểm sát">Viện kiểm sát</option>
                                <option value="Đương sự">Đương sự</option>
                              </select>
                            ) : (
                              r.noiNhan
                            )}
                          </td>
                          <td style={TD_STYLE}>
                            {editingId === r.id ? (
                              <input
                                type="text"
                                value={editChiTiet}
                                onChange={e => setEditChiTiet(e.target.value)}
                                style={{ ...inSt, padding: "4px 8px" }}
                              />
                            ) : (
                              r.noiNhanChiTiet
                            )}
                          </td>
                          <td style={TD_STYLE}>
                            {editingId === r.id ? (
                              <input
                                type="text"
                                value={editGhiChu}
                                onChange={e => setEditGhiChu(e.target.value)}
                                style={{ ...inSt, padding: "4px 8px" }}
                              />
                            ) : (
                              r.ghiChu
                            )}
                          </td>
                          <td style={{ ...TD_STYLE, textAlign: "center" }}>
                            {editingId === r.id ? (
                              <div style={{ display: "flex", gap: 6, justifyContent: "center" }}>
                                <button
                                  type="button"
                                  onClick={() => handleSaveEdit(r.id)}
                                  style={{ background: "none", border: "none", color: "#16a34a", fontWeight: 700, cursor: "pointer", fontSize: 11 }}
                                >
                                  Lưu
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEditingId(null)}
                                  style={{ background: "none", border: "none", color: MUTED, cursor: "pointer", fontSize: 11 }}
                                >
                                  Hủy
                                </button>
                              </div>
                            ) : (
                              <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
                                <button
                                  type="button"
                                  onClick={() => handleStartEdit(r)}
                                  style={{ background: "none", border: "none", color: "#2563eb", cursor: "pointer", fontSize: 11 }}
                                >
                                  ✏ Sửa
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteNoiNhan(r.id)}
                                  style={{ background: "none", border: "none", color: "#dc2626", cursor: "pointer", fontSize: 11 }}
                                >
                                  🗑 Xóa
                                </button>
                              </div>
                            )}
                          </td>
                        </tr>
                      ))}

                      {/* Add new inline row */}
                      {isAddingNoiNhan && (
                        <tr style={{ background: "#f0fdf4", borderBottom: `1px solid ${BORDER}` }}>
                          <td style={{ ...TD_STYLE, textAlign: "center", color: MUTED }}>{noiNhanList.length + 1}</td>
                          <td style={TD_STYLE}>
                            <select
                              value={newNoiNhan}
                              onChange={e => setNewNoiNhan(e.target.value)}
                              style={{ ...inSt, padding: "4px 8px" }}
                            >
                              <option value="Khác">Khác</option>
                              <option value="Tòa án nhân dân">Tòa án nhân dân</option>
                              <option value="Viện kiểm sát nhân dân">Viện kiểm sát nhân dân</option>
                              <option value="Cơ quan thi hành án hình sự">Cơ quan thi hành án hình sự</option>
                              <option value="Cơ quan thi hành án dân sự">Cơ quan thi hành án dân sự</option>
                              <option value="Trại giam">Trại giam</option>
                              <option value="Trại tạm giam">Trại tạm giam</option>
                              <option value="Viện kiểm sát">Viện kiểm sát</option>
                              <option value="Đương sự">Đương sự</option>
                            </select>
                          </td>
                          <td style={TD_STYLE}>
                            <input
                              type="text"
                              placeholder="Nhập nơi nhận chi tiết"
                              value={newChiTiet}
                              onChange={e => setNewChiTiet(e.target.value)}
                              style={{ ...inSt, padding: "4px 8px" }}
                            />
                          </td>
                          <td style={TD_STYLE}>
                            <input
                              type="text"
                              placeholder="Ghi chú"
                              value={newGhiChu}
                              onChange={e => setNewGhiChu(e.target.value)}
                              style={{ ...inSt, padding: "4px 8px" }}
                            />
                          </td>
                          <td style={{ ...TD_STYLE, textAlign: "center" }}>
                            <div style={{ display: "flex", gap: 6, justifyContent: "center" }}>
                              <button
                                type="button"
                                onClick={handleSaveNewNoiNhan}
                                style={{ background: "none", border: "none", color: "#16a34a", fontWeight: 700, cursor: "pointer", fontSize: 11 }}
                              >
                                Lưu
                              </button>
                              <button
                                type="button"
                                onClick={() => setIsAddingNoiNhan(false)}
                                style={{ background: "none", border: "none", color: MUTED, cursor: "pointer", fontSize: 11 }}
                              >
                                Hủy
                              </button>
                            </div>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div style={{ display: "flex", justifyContent: "center", gap: 10, padding: "12px 20px", borderTop: `1px solid ${BORDER}`, flexShrink: 0, flexWrap: "wrap" }}>
            <button
              type="button"
              onClick={onClose}
              style={{ padding: "7px 20px", background: "#fff", color: TEXT, border: `1px solid ${BORDER}`, borderRadius: 4, cursor: "pointer", fontSize: 12, fontFamily: F }}
            >
              Đóng
            </button>
            <button
              type="button"
              onClick={handleSave}
              style={{ padding: "7px 24px", background: RED, color: "#fff", border: "none", borderRadius: 4, cursor: "pointer", fontSize: 12, fontWeight: 700, fontFamily: F }}
            >
              Lưu
            </button>
            {(isTraLoi || isVks || isKhangNghi) && (
              <button
                type="button"
                onClick={handleToggleLaySo}
                style={{
                  padding: "7px 20px",
                  background: daLaySo ? "#fef2f2" : "#fff",
                  color: daLaySo ? "#dc2626" : TEXT,
                  border: `1px solid ${daLaySo ? "#fca5a5" : BORDER}`,
                  borderRadius: 4,
                  cursor: "pointer",
                  fontSize: 12,
                  fontFamily: F,
                }}
              >
                {daLaySo ? "✕ Hủy cấp số" : "Lấy số"}
              </button>
            )}
            {(isTraLoi || isVks || isKhangNghi) && (
              <button
                type="button"
                onClick={() => setShowTrinhKy(true)}
                style={{ padding: "7px 20px", background: RED, color: "#fff", border: "none", borderRadius: 4, cursor: "pointer", fontSize: 12, fontWeight: 700, fontFamily: F }}
              >
                {hinhThucTrinh === "trinh-duyet" ? "Trình duyệt" : "Trình ký"}
              </button>
            )}
            {!isXepDon && (
              <button
                type="button"
                onClick={() => setShowBieuMau(true)}
                style={{ padding: "7px 20px", background: "#fff", color: TEXT, border: `1px solid ${BORDER}`, borderRadius: 4, cursor: "pointer", fontSize: 12, fontFamily: F }}
              >
                Xem biểu mẫu
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Modal Xem / Quản lý tài liệu hồ sơ số hóa */}
      {showTaiLieuHoSoModal && (
        <div style={{ position: "fixed", inset: 0, zIndex: 2000, background: "#fff", display: "flex", flexDirection: "column" }}>
          <div style={{ padding: "8px 16px", background: "#800000", color: "#fff", display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
            <span style={{ fontSize: 13, fontWeight: 700, fontFamily: F }}>📁 Quản lý tài liệu hồ sơ số hóa - Vụ án {maVuAn}</span>
            <button onClick={() => setShowTaiLieuHoSoModal(false)} style={{ background: "none", border: "none", color: "#fff", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, fontSize: 12, fontWeight: 600, fontFamily: F }}>
              <X size={16} /> Đóng xem hồ sơ
            </button>
          </div>
          <div style={{ flex: 1, overflow: "hidden" }}>
            <TaiLieuHoSoView vuAnId={maVuAn} tenVuAn={tenVuAn} onBack={() => setShowTaiLieuHoSoModal(false)} />
          </div>
        </div>
      )}

      {/* Modal Thêm người đứng đơn */}
      {/* {showAddNguoiModal && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1200, background: "rgba(0,0,0,0.5)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ background: "#fff", borderRadius: 8, width: 440, padding: 20, boxShadow: "0 8px 30px rgba(0,0,0,0.2)", fontFamily: F }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
              <span style={{ fontSize: 14, fontWeight: 700, color: "#111827" }}>Thêm người đứng đơn</span>
              <button onClick={() => setShowAddNguoiModal(false)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 18, color: MUTED }}>✕</button>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <div>
                <label style={lblSt}><span style={{ color: "#dc2626", marginRight: 3 }}>*</span>Chọn đơn thuộc người đứng đơn</label>
                <select value={newNguoiDonId} onChange={e => setNewNguoiDonId(e.target.value)} style={inSt}>
                  {donDataList.map(d => (
                    <option key={d.id} value={d.id}>{d.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label style={lblSt}><span style={{ color: "#dc2626", marginRight: 3 }}>*</span>Họ và tên người đứng đơn</label>
                <input
                  type="text"
                  placeholder="Nhập họ và tên người đứng đơn"
                  value={newNguoiTen}
                  onChange={e => setNewNguoiTen(e.target.value)}
                  style={inSt}
                />
              </div>
            </div>

            <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 18 }}>
              <button onClick={() => setShowAddNguoiModal(false)} style={{ padding: "6px 16px", background: "#fff", border: `1px solid ${BORDER}`, borderRadius: 4, cursor: "pointer", fontSize: 12, fontFamily: F }}>Hủy</button>
              <button onClick={handleAddNewNguoiDungDon} style={{ padding: "6px 18px", background: "#800000", color: "#fff", border: "none", borderRadius: 4, cursor: "pointer", fontSize: 12, fontWeight: 700, fontFamily: F }}>Lưu</button>
            </div>
          </div>
        </div>
      )} */}

      {/* Modal Trình ký */}
      {showTrinhKy && (
        <TrinhKyModal
          onClose={() => setShowTrinhKy(false)}
          record={{
            loaiVB: ketQua === "khang-nghi" ? "Quyết định kháng nghị" : "Thông báo trả lời đơn",
            soHoSo: "01",
            donViSoan: "Vụ 1 - TANDTC",
          }}
        />
      )}

      {/* Modal Xem biểu mẫu */}
      {showBieuMau && (
        <XemBieuMauDuThaoModal
          onClose={() => setShowBieuMau(false)}
          detail={detail}
          ketQua={ketQua === "khang-nghi" ? "khang-nghi" : "tra-loi"}
          soQuyetDinh={soQuyetDinh || "179/2026/TB-TA"}
          ngayQuyetDinh={ngayQuyetDinh || "09/08/2026"}
          nguoiKy={nguoiKy}
          noiDung={noiDung || "Căn cứ vào tài liệu, chứng cứ có trong hồ sơ vụ án..."}
        />
      )}
    </>
  );
}

// ── Modal Thêm quyết định hoãn thi hành án riêng biệt ────────────────────────
export function ThemQuyetDinhHoanModal({
  onClose,
  detail,
  onSave,
}: {
  onClose: () => void;
  detail?: any;
  onSave?: (data: any) => void;
}) {
  const maVuAn = detail?.maVuAn || "VA26-00321";
  const tenVuAn = detail?.tenVuAn || "Vụ án Phan Văn Thành – bức cung";
  const biCaoOptions = Array.from(
    new Set([
      detail?.biCao,
      detail?.tenBiCan,
      "Phan Văn Thành (Bị cáo đầu vụ)",
      "Nguyễn Văn Minh (Bị cáo)",
      "Trần Đình Trọng (Bị cáo)",
      "Lê Văn Hùng (Bị cáo)",
    ].filter(Boolean))
  ) as string[];

  const [selectedBiCao, setSelectedBiCao] = useState(biCaoOptions[0] || "Phan Văn Thành (Bị cáo đầu vụ)");
  const [canCuRows, setCanCuRows] = useState<Array<{ id: number; boLuat: string; dieu: string; khoan: string; diem: string }>>([
    { id: 1, boLuat: "Bộ luật Tố tụng hình sự", dieu: "Điều 377", khoan: "1", diem: "" },
  ]);
  const [qdTamDinhChi, setQdTamDinhChi] = useState<Array<{ id: number; banAn: string; phanQuyetDinh: string; hinhPhat: string }>>([]);
  const [daLaySoQD, setDaLaySoQD] = useState(false);
  const [tenQuyetDinh, setTenQuyetDinh] = useState("Quyết định tạm hoãn chấp hành án phạt tù");
  const [soQuyetDinh, setSoQuyetDinh] = useState("08/2026/QĐ-THTHA");
  const [ngayQuyetDinh, setNgayQuyetDinh] = useState("10/07/2026");
  const [nguoiKy, setNguoiKy] = useState("Nguyễn Hòa Bình – Chánh án TANDTC");
  const [thoiHan, setThoiHan] = useState("06 tháng");
  const [ngayPhatHanh, setNgayPhatHanh] = useState("10/07/2026");
  const [coQuanTHA, setCoQuanTHA] = useState("Cơ quan THA hình sự Công an tỉnh Hải Phòng");
  const [lyDo, setLyDo] = useState("Chờ kết quả xét xử theo thủ tục giám đốc thẩm đối với bản án hình sự phúc thẩm.");

  const [nnRows, setNnRows] = useState([
    { id: 1, noiNhan: "Viện kiểm sát", chiTiet: "VKSND Tối cao", ghiChu: "để kiểm sát" },
    { id: 2, noiNhan: "Cơ quan THA", chiTiet: "Cơ quan THA hình sự Công an tỉnh Hải Phòng", ghiChu: "để thi hành" },
    { id: 3, noiNhan: "Trại tạm giam", chiTiet: "Trại tạm giam Công an tỉnh Hải Phòng", ghiChu: "để thực hiện" },
  ]);
  const [addingRow, setAddingRow] = useState(false);
  const [newRow, setNewRow] = useState({ noiNhan: "", chiTiet: "", ghiChu: "" });

  const inSt: React.CSSProperties = { padding: "8px 10px", fontSize: 12, border: `1px solid ${BORDER}`, borderRadius: 4, fontFamily: F, outline: "none", width: "100%", background: "#fff", boxSizing: "border-box" };
  const lblSt: React.CSSProperties = { fontSize: 12, color: TEXT, fontWeight: 600, fontFamily: F, display: "block", marginBottom: 5 };

  const handleSave = () => {
    if (onSave) {
      onSave({
        stt: 1,
        biCao: selectedBiCao,
        tenQuyetDinh,
        soQuyetDinh,
        ngayQuyetDinh,
        nguoiKy,
        nguoiTao: "Lý Thái Phúc (TTV)",
      });
    }
    alert("Đã lưu quyết định hoãn thi hành án thành công!");
    onClose();
  };

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 1100, background: "rgba(0,0,0,0.45)", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ background: "#fff", borderRadius: 8, width: "min(860px, 96vw)", maxHeight: "92vh", display: "flex", flexDirection: "column", boxShadow: "0 8px 32px rgba(0,0,0,0.2)", fontFamily: F, overflow: "hidden" }}>
        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", padding: "14px 20px", borderBottom: `1px solid ${BORDER}`, flexShrink: 0 }}>
          <FileText size={16} color={RED} style={{ marginRight: 8 }} />
          <span style={{ fontSize: 15, fontWeight: 700, color: TEXT, flex: 1 }}>
            Thêm mới quyết định hoãn thi hành án
          </span>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 20, color: MUTED, lineHeight: 1 }}>×</button>
        </div>

        <div style={{ flex: 1, overflowY: "auto", padding: "16px 20px" }}>
          {/* Info card */}
          <div style={{ background: "#f0fdf4", border: `1px solid #bbf7d0`, borderRadius: 6, padding: "10px 16px", marginBottom: 16, display: "grid", gridTemplateColumns: "1.2fr 1fr 1fr", gap: "6px 16px", fontSize: 11 }}>
            <div><span style={{ color: MUTED }}>Mã vụ án: </span><span style={{ color: "#0f766e", fontWeight: 700 }}>{maVuAn}</span></div>
            <div><span style={{ color: MUTED }}>Số BA/QĐ: </span><span style={{ color: "#0f766e", fontWeight: 600 }}>050526_CTH02</span></div>
            <div><span style={{ color: MUTED }}>Giai đoạn: </span><span style={{ color: "#0f766e", fontWeight: 600 }}>Giám đốc thẩm, tái thẩm</span></div>
            <div><span style={{ color: MUTED }}>Tên vụ án: </span><span style={{ color: "#0f766e", fontWeight: 600 }}>{tenVuAn}</span></div>
            <div><span style={{ color: MUTED }}>Ngày ra BA/QĐ: </span><span style={{ color: "#0f766e", fontWeight: 600 }}>05/05/2026</span></div>
            <div><span style={{ color: MUTED }}>Tòa án giải quyết: </span><span style={{ color: "#0f766e", fontWeight: 600 }}>Tòa án nhân dân tối cao</span></div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 12 }}>
            <div>
              <label style={lblSt}><span style={{ color: RED }}>* </span>Tên Bị cáo</label>
              <select value={selectedBiCao} onChange={e => setSelectedBiCao(e.target.value)} style={{ ...inSt, cursor: "pointer" }}>
                {biCaoOptions.map(bc => (
                  <option key={bc} value={bc}>{bc}</option>
                ))}
              </select>
            </div>
            <div>
              <label style={lblSt}><span style={{ color: RED }}>* </span>Tên quyết định</label>
              <input value={tenQuyetDinh} onChange={e => setTenQuyetDinh(e.target.value)} placeholder="Nhập tên quyết định hoãn" style={inSt} />
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 12, marginBottom: 12 }}>
            <div>
              <label style={lblSt}><span style={{ color: RED }}>* </span>Số quyết định</label>
              <input value={soQuyetDinh} onChange={e => setSoQuyetDinh(e.target.value)} placeholder="Nhập số QĐ" style={inSt} />
            </div>
            <div>
              <label style={lblSt}><span style={{ color: RED }}>* </span>Ngày ra quyết định</label>
              <input value={ngayQuyetDinh} onChange={e => setNgayQuyetDinh(e.target.value)} placeholder="dd/mm/yyyy" style={inSt} />
            </div>
            <div>
              <label style={lblSt}>Thời hạn hoãn</label>
              <input value={thoiHan} onChange={e => setThoiHan(e.target.value)} placeholder="VD: 06 tháng" style={inSt} />
            </div>
            <div>
              <label style={lblSt}>Ngày phát hành</label>
              <input value={ngayPhatHanh} onChange={e => setNgayPhatHanh(e.target.value)} placeholder="dd/mm/yyyy" style={inSt} />
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 12 }}>
            <div>
              <label style={lblSt}><span style={{ color: RED }}>* </span>Người ký ban hành</label>
              <select value={nguoiKy} onChange={e => setNguoiKy(e.target.value)} style={{ ...inSt, cursor: "pointer" }}>
                <option value="Nguyễn Hòa Bình – Chánh án TANDTC">Nguyễn Hòa Bình – Chánh án TANDTC</option>
                <option value="Lê Minh Trí – Phó Chánh án TANDTC">Lê Minh Trí – Phó Chánh án TANDTC</option>
                <option value="Phạm Quốc Tuấn – Phó Chánh án TANDTC">Phạm Quốc Tuấn – Phó Chánh án TANDTC</option>
              </select>
            </div>
            <div>
              <label style={lblSt}>Cơ quan thi hành án</label>
              <input value={coQuanTHA} onChange={e => setCoQuanTHA(e.target.value)} placeholder="Nhập cơ quan THA" style={inSt} />
            </div>
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={lblSt}><span style={{ color: RED }}>* </span>Lý do / Nội dung hoãn thi hành án</label>
            <textarea value={lyDo} onChange={e => setLyDo(e.target.value)} placeholder="Nhập lý do và nội dung chi tiết của quyết định hoãn..." rows={3} style={{ ...inSt, resize: "vertical", lineHeight: 1.5 }} />
          </div>

          {/* TH-082: Căn cứ điều luật */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
              <label style={{ ...lblSt, marginBottom: 0 }}><span style={{ color: RED }}>* </span>Căn cứ điều luật</label>
              <button onClick={() => setCanCuRows(p => [...p, { id: Date.now(), boLuat: "Bộ luật Tố tụng hình sự", dieu: "", khoan: "", diem: "" }])}
                style={{ padding: "4px 12px", background: RED, color: "#fff", border: "none", borderRadius: 4, cursor: "pointer", fontSize: 11, fontWeight: 600, fontFamily: F }}>+ Thêm điều luật</button>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
              <thead>
                <tr style={{ background: "#f8fafc", borderBottom: `1px solid ${BORDER}` }}>
                  {["Bộ luật", "Điều luật", "Khoản", "Điểm", ""].map(h => <th key={h} style={TH_STYLE}>{h}</th>)}
                </tr>
              </thead>
              <tbody>
                {canCuRows.length === 0 && (
                  <tr><td colSpan={5} style={{ ...TD_STYLE, textAlign: "center", color: MUTED, padding: 14 }}>Chưa có căn cứ điều luật</td></tr>
                )}
                {canCuRows.map((r, i) => (
                  <tr key={r.id}>
                    <td style={TD_STYLE}>
                      <select value={r.boLuat} onChange={e => setCanCuRows(p => p.map((x, j) => j === i ? { ...x, boLuat: e.target.value } : x))}
                        style={{ width: "100%", border: "none", fontSize: 12, outline: "none", fontFamily: F }}>
                        <option>Bộ luật Tố tụng hình sự</option>
                        <option>Bộ luật Tố tụng dân sự</option>
                        <option>Luật Tố tụng hành chính</option>
                      </select>
                    </td>
                    {(["dieu", "khoan", "diem"] as const).map(k => (
                      <td key={k} style={TD_STYLE}>
                        <input value={r[k]} onChange={e => setCanCuRows(p => p.map((x, j) => j === i ? { ...x, [k]: e.target.value } : x))}
                          style={{ width: "100%", border: "none", fontSize: 12, outline: "none", fontFamily: F }} />
                      </td>
                    ))}
                    <td style={{ ...TD_STYLE, textAlign: "center" }}>
                      <button onClick={() => setCanCuRows(p => p.filter((_, j) => j !== i))}
                        style={{ background: "none", border: "none", cursor: "pointer", color: "#ef4444", fontSize: 11 }}>Xóa</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* TH-082: Bảng quyết định tạm đình chỉ thi hành án */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
              <label style={{ ...lblSt, marginBottom: 0 }}><span style={{ color: RED }}>* </span>Quyết định tạm đình chỉ</label>
              <button onClick={() => setQdTamDinhChi(p => [...p, { id: Date.now(), banAn: "", phanQuyetDinh: "Hình phạt đối với bị cáo", hinhPhat: "" }])}
                style={{ padding: "4px 12px", background: RED, color: "#fff", border: "none", borderRadius: 4, cursor: "pointer", fontSize: 11, fontWeight: 600, fontFamily: F }}>+ Thêm quyết định</button>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
              <thead>
                <tr style={{ background: "#f8fafc", borderBottom: `1px solid ${BORDER}` }}>
                  {["Bản án / Quyết định", "Phần quyết định", "Hình phạt chi tiết", ""].map(h => <th key={h} style={TH_STYLE}>{h}</th>)}
                </tr>
              </thead>
              <tbody>
                {qdTamDinhChi.length === 0 && (
                  <tr><td colSpan={4} style={{ ...TD_STYLE, textAlign: "center", color: MUTED, padding: 14 }}>Chưa có quyết định</td></tr>
                )}
                {qdTamDinhChi.map((r, i) => (
                  <tr key={r.id}>
                    <td style={TD_STYLE}>
                      <input value={r.banAn} onChange={e => setQdTamDinhChi(p => p.map((x, j) => j === i ? { ...x, banAn: e.target.value } : x))}
                        placeholder="Số – ngày bản án/QĐ" style={{ width: "100%", border: "none", fontSize: 12, outline: "none", fontFamily: F }} />
                    </td>
                    <td style={TD_STYLE}>
                      <select value={r.phanQuyetDinh} onChange={e => setQdTamDinhChi(p => p.map((x, j) => j === i ? { ...x, phanQuyetDinh: e.target.value } : x))}
                        style={{ width: "100%", border: "none", fontSize: 12, outline: "none", fontFamily: F }}>
                        <option>Hình phạt đối với bị cáo</option>
                        <option>Trách nhiệm dân sự</option>
                        <option>Xử lý vật chứng</option>
                        <option>Án phí</option>
                      </select>
                    </td>
                    <td style={TD_STYLE}>
                      <input value={r.hinhPhat} onChange={e => setQdTamDinhChi(p => p.map((x, j) => j === i ? { ...x, hinhPhat: e.target.value } : x))}
                        style={{ width: "100%", border: "none", fontSize: 12, outline: "none", fontFamily: F }} />
                    </td>
                    <td style={{ ...TD_STYLE, textAlign: "center" }}>
                      <button onClick={() => setQdTamDinhChi(p => p.filter((_, j) => j !== i))}
                        style={{ background: "none", border: "none", cursor: "pointer", color: "#ef4444", fontSize: 11 }}>Xóa</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Nơi nhận */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
              <label style={{ ...lblSt, marginBottom: 0 }}><span style={{ color: RED }}>* </span>Nơi nhận</label>
              <button onClick={() => setAddingRow(true)} style={{ padding: "4px 12px", background: RED, color: "#fff", border: "none", borderRadius: 4, cursor: "pointer", fontSize: 11, fontWeight: 600, fontFamily: F }}>+ Thêm nơi nhận</button>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
              <thead>
                <tr style={{ background: "#f8fafc", borderBottom: `1px solid ${BORDER}` }}>
                  <th style={{ ...TH_STYLE, width: 40, textAlign: "center" }}>STT</th>
                  <th style={{ ...TH_STYLE, width: 140 }}>Nơi nhận</th>
                  <th style={{ ...TH_STYLE }}>Nơi nhận chi tiết</th>
                  <th style={{ ...TH_STYLE, width: 140 }}>Ghi chú</th>
                  <th style={{ ...TH_STYLE, width: 70, textAlign: "center" }}>Thao tác</th>
                </tr>
              </thead>
              <tbody>
                {nnRows.map((r, i) => (
                  <tr key={r.id} style={{ borderBottom: `1px solid ${BORDER}` }}>
                    <td style={{ ...TD_STYLE, textAlign: "center", color: MUTED }}>{i + 1}</td>
                    <td style={TD_STYLE}>{r.noiNhan}</td>
                    <td style={TD_STYLE}>{r.chiTiet}</td>
                    <td style={TD_STYLE}>{r.ghiChu}</td>
                    <td style={{ ...TD_STYLE, textAlign: "center" }}>
                      <button onClick={() => setNnRows(p => p.filter(x => x.id !== r.id))} style={{ background: "none", border: "none", cursor: "pointer", color: "#ef4444", fontSize: 11 }}>Xóa</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer */}
        <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, padding: "12px 20px", borderTop: `1px solid ${BORDER}`, background: "#fff", flexShrink: 0 }}>
          <button onClick={onClose} style={{ padding: "7px 20px", background: "#fff", color: TEXT, border: `1px solid ${BORDER}`, borderRadius: 4, cursor: "pointer", fontSize: 13, fontFamily: F }}>Đóng</button>
          <button
            onClick={() => { setDaLaySoQD(v => !v); if (!daLaySoQD) setSoQuyetDinh("08/2026/QĐ-TĐCTHA"); else setSoQuyetDinh(""); }}
            style={{ padding: "7px 18px", background: "#fff", color: TEXT, border: `1px solid ${BORDER}`, borderRadius: 4, cursor: "pointer", fontSize: 13, fontFamily: F }}>
            {daLaySoQD ? "Hủy lấy số" : "Lấy số"}
          </button>
          <button style={{ padding: "7px 18px", background: "#fff", color: TEXT, border: `1px solid ${BORDER}`, borderRadius: 4, cursor: "pointer", fontSize: 13, fontFamily: F }}>Xem biểu mẫu</button>
          <button style={{ padding: "7px 18px", background: "#fff", color: TEXT, border: `1px solid ${BORDER}`, borderRadius: 4, cursor: "pointer", fontSize: 13, fontFamily: F }}>Trình ký</button>
          <button onClick={handleSave} style={{ padding: "7px 24px", background: RED, color: "#fff", border: "none", borderRadius: 4, cursor: "pointer", fontSize: 13, fontWeight: 700, fontFamily: F }}>Lưu</button>
        </div>
      </div>
    </div>
  );
}
